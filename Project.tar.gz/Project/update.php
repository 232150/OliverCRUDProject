<HTML>
	<head></head><body>
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") 
    {//Check it is coming from a form
    
		//mysql credentials
    $mysql_host = "localhost";
    $mysql_username = "oliver7073";
    $mysql_password = "Op052203";
    $mysql_database = "LoLRankTracker";
	
	$item = $_POST["update"];
    
	
	$conn = new mysqli($mysql_host, $mysql_username, $mysql_password, $mysql_database);
	if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
	}
	
        $sql = "SELECT * FROM student WHERE Username='" . $_POST['update'] . "'";
        $result = $conn->query($sql);
	
	    $Username = $row[0];
        $Division= $row[1];
        $LP = $row[2];

                        // HTML to display the form on this page.
                     echo "<form action='changeItem.php' method = 'post'>";
                     echo "<TD><input type='text' placeholder='Username' name='Username' Division='advancedSearchTextBox'></TD>";
                     
                    echo "<TD><select id='select' name='Division'>";
                        echo "<option value='Bronze' >Bronze</option>";
                        echo "<option value='Silver' >Silver</option>";
                        echo "<option value='Gold' >Gold</option>";
                        echo "<option value='Platinum' >Platinum</option>";
                        echo "<option value='Diamond' >Diamond</option>";
                        echo "<option value='Master' >Master</option>";
                        echo "<option value='Challenger' >Challenger</option>";
                     echo  "<input type='text' placeholder='LP' name='LP'>";
                        echo "<input name = 'create' type = 'submit' value = 'Submit Changes'>";
                        echo "</form>";
                          
	                    
                    } 
                 echo "</body>"; 
	
?>
<body background="http://intrewallpaper.com/wp-content/uploads/4k-nature-desktop-wallpaper.jpg"> 
       <br><form action= 'Goback.php' method = 'get'>
           </style>
        <title>Data</title>
         <link href="icecream.css" rel="stylesheet" type="text/css"> 
        </style>
      <input name = 'back'   type = 'submit' value = 'Go Back'></form>