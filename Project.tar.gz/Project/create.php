<?php
//process.php
if ($_SERVER["REQUEST_METHOD"] == "POST") 
    {//Check it is coming from a form
    
		//mysql credentials
    $mysql_host = "localhost";
    $mysql_username = "oliver7073";
    $mysql_password = "Op052203";
    $mysql_database = "LoLRankTracker";
	
	//delcare PHP variables
	
	$Username = $_POST["Username"];
	$Division = $_POST["Division"];
	$LP = $_POST["LP"];
	
	//Open a new connection to the MySQL server
	//see https://www.sanwebe.com/2013/03/basic-php-mysqli-usage for more info
	$mysqli = new mysqli($mysql_host, $mysql_username, $mysql_password, $mysql_database);
	
	//Output any connection error
	if ($mysqli->connect_error) {
		die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
	}   
	
		$statement = $mysqli->prepare("INSERT INTO Rank (Username, LP, Division) VALUES(?, ?, ?)"); //prepare sql insert query
		//bind parameters for markers, where (s = string, i = integer, d = double,  b = blob)
		$statement->bind_param('sss', $Username, $LP, $Division); //bind value
		if($statement->execute())
			{
				//print output text
					echo nl2br("Hello "." ". $Username . "! You are in " .$Division.  "\r\n with  ". $LP. "LP. Your information has been saved!"  , false);
			}
			else{
					print $mysqli->error; //show mysql error if any 
				}

echo"<br><form action= 'Goback.php' method = 'get'>";
echo "<input name = 'back'   type = 'submit' value = 'Go Back'></form>";
         }
else{
    echo ("error");
    }         
?>
<body background="http://intrewallpaper.com/wp-content/uploads/4k-nature-desktop-wallpaper.jpg"> 
</style>
        <title>Data</title>
         <link href="icecream.css" rel="stylesheet" type="text/css"> 
        </style>
