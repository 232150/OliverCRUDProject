<?php
$host = "localhost";
$dbname ="LoLRankTracker";
$username = "oliver7073";
$password = "Op052203";
?>
