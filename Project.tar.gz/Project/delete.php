<HTML>
	<head></head><body>
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") 
    {//Check it is coming from a form
    
		//mysql credentials
    $mysql_host = "localhost";
    $mysql_username = "oliver7073";
    $mysql_password = "Op052203";
    $mysql_database = "LoLRankTracker";
	
	$item = $_POST["delete"];
	
	$conn = new mysqli($mysql_host, $mysql_username, $mysql_password, $mysql_database);
	if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
	}
	
	$sql = "Delete FROM Rank WHERE Username='" . $_POST['delete'] . "'";
	$result = $conn->query($sql);
echo $item." has been deleted.";		
echo"<br><form action= 'Goback.php' method = 'get'>";
echo "<input name = 'back'   type = 'submit' value = 'Go Back'></form>";

         }
else{
    echo ("error");
    }         
?>
</body>
<body background="http://intrewallpaper.com/wp-content/uploads/4k-nature-desktop-wallpaper.jpg"> 
       <br><form action= 'Goback.php' method = 'get'>
           </style>
        <title>Data</title>
         <link href="icecream.css" rel="stylesheet" type="text/css"> 
        </style>