<?php
   $dbhost = 'localhost';
   $dbuser = 'oliver7073';
   $dbpass = 'Op052203';
   
   $conn = mysql_connect($dbhost, $dbuser, $dbpass);
   
   if(! $conn ) {
      die('Could not connect: ' . mysql_error());
   }
   
   $sql = 'SELECT Username, Division, LP FROM Rank';
   mysql_select_db('LoLRankTracker');
   $retval = mysql_query( $sql, $conn );
   
   if(! $retval ) {
      die('Could not get data: ' . mysql_error());
   }
   
$Username = $row[0];
$Division = $row[1];
$LP= $row[2];

   while($row = mysql_fetch_assoc($retval)) {
     // The following few lines store information from specific cells in the data about an image
			echo "<TR>";
			echo "<TD>Username:".$row['Username']. "_Division:". $row['Division']. "_".$row['LP'] ."LP</TD>";
			echo "<TD><form action= 'update.php' method = 'post'>";
			echo "<button name = 'update'   type = 'submit' value =".$row['Username'].">Edit</button></FORM>";
			echo "<TD><form action= 'delete.php' method = 'post'>";
			echo "<button name = 'delete'   type = 'submit' value =".$row['Username'].">Delete</button></FORM>";
			echo "</TR>";
   }
   
   echo "Fetched data successfully\n";
   
   mysql_close($conn);
   
?>
<body background="http://intrewallpaper.com/wp-content/uploads/4k-nature-desktop-wallpaper.jpg"> 
</style>
        <title>Data</title>
         <link href="icecream.css" rel="stylesheet" type="text/css"> 
        </style>
       <br><form action= 'Goback.php' method = 'get'>
      <input name = 'back'   type = 'submit' value = 'Go Back'></form>
